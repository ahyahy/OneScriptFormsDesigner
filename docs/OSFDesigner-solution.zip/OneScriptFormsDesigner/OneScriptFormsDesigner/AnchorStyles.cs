﻿namespace osfDesigner
{
    [System.Flags]

    public enum AnchorStyles
    {
        Верх = 1,
        Лево = 4,
        Низ = 2,
        Отсутствие = 0,
        Право = 8
    }
}
