﻿namespace osfDesigner
{
    public enum Appearance
    {
        Кнопка = 1,
        Стандартное = 0
    }
}
