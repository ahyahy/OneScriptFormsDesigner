﻿namespace osfDesigner
{
    public enum BorderStyle
    {
        Одинарная = 1,
        Отсутствие = 0,
        Трехмерная = 2
    }
}
