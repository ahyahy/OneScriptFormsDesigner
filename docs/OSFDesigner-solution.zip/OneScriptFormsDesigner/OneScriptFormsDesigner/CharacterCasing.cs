﻿namespace osfDesigner
{
    public enum CharacterCasing
    {
        Верхний = 1,
        Нижний = 2,
        Стандартный = 0
    }
}
