﻿namespace osfDesigner
{
    public enum CheckState
    {
        Неопределенный = 2,
        НеПомечен = 0,
        Помечен = 1
    }
}
