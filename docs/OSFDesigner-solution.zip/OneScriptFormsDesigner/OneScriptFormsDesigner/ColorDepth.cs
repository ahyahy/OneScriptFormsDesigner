﻿namespace osfDesigner
{
    public enum ColorDepth
    {
        Глубина16 = 16,
        Глубина24 = 24,
        Глубина32 = 32,
        Глубина4 = 4,
        Глубина8 = 8
    }
}
