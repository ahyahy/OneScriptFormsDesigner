﻿namespace osfDesigner
{
    public enum ColumnHeaderStyle
    {
        Нажимаемая = 2,
        НеНажимаемая = 1,
        Отсутствие = 0
    }
}
