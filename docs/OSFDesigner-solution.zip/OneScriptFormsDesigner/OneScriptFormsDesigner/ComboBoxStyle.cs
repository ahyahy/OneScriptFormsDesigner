﻿namespace osfDesigner
{
    public enum ComboBoxStyle
    {
        НеРедактируемый = 2,
        Простой = 0,
        Редактируемый = 1
    }
}
