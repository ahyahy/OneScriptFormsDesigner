﻿namespace osfDesigner
{
    public enum DataType
    {
        Булево = 2,
        Дата = 3,
        Строка = 0,
        Число = 1
    }
}
