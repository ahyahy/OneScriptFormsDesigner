﻿namespace osfDesigner
{
    public enum DialogResult
    {
        Да = 6,
        Нет = 7,
        ОК = 1,
        Отмена = 2,
        Отсутствие = 0,
        Повторить = 4,
        Прервать = 3,
        Пропустить = 5
    }
}
