﻿namespace osfDesigner
{
    public enum DockStyle
    {
        Верх = 1,
        Заполнение = 5,
        Лево = 3,
        Низ = 2,
        Отсутствие = 0,
        Право = 4
    }
}
