﻿namespace osfDesigner
{
    public enum DrawMode
    {
        ВручнуюПеременный = 2,
        ВручнуюФиксированный = 1,
        Стандартный = 0
    }
}
