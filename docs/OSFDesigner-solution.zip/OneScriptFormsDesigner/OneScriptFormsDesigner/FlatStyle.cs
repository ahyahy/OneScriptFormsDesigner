﻿namespace osfDesigner
{
    public enum FlatStyle
    {
        Всплывающий = 1,
        Плоский = 0,
        Система = 3,
        Стандартный = 2
    }
}
