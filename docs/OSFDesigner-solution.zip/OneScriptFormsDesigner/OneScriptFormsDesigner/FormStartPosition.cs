﻿namespace osfDesigner
{
    public enum FormStartPosition
    {
        Вручную = 0,
        ГраницыОкнаПоУмолчанию = 3,
        ПоложениеОкнаПоУмолчанию = 2,
        ЦентрРодителя = 4,
        ЦентрЭкрана = 1
    }
}
