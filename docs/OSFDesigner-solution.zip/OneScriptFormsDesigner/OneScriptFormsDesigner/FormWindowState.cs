﻿namespace osfDesigner
{
    public enum FormWindowState
    {
        Развернутое = 2,
        Свернутое = 1,
        Стандартное = 0
    }
}
