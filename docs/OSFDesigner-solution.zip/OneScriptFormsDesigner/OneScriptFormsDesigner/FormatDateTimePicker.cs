﻿namespace osfDesigner
{
    [System.Flags]
    public enum FormatDateTimePicker
    {
        Время = 4,
        Длинный = 1,
        Короткий = 2,
        Пользовательский = 8
    }
}
