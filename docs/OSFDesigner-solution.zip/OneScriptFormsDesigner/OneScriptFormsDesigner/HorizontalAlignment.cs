﻿namespace osfDesigner
{
    public enum HorizontalAlignment
    {
        Лево = 0,
        Право = 1,
        Центр = 2
    }
}
