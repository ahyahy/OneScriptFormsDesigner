﻿using System.Windows.Forms;

namespace osfDesigner
{
    public interface IDesignerMainForm
    {
        void ChangeImage(bool change);
        Control GetmainForm();
    }
}
