﻿namespace osfDesigner
{
    public enum ImageLayout
    {
        Масштабировать = 4,
        Мозаика = 1,
        Отсутствие = 0,
        Растянуть = 3,
        Центр = 2
    }
}
