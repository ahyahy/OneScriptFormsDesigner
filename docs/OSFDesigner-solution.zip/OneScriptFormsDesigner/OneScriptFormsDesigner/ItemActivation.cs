﻿namespace osfDesigner
{
    public enum ItemActivation
    {
        ДваНажатия = 2,
        ОдноНажатие = 1,
        Стандартная = 0
    }
}
