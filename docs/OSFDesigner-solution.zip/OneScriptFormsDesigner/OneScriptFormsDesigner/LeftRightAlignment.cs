﻿namespace osfDesigner
{
    public enum LeftRightAlignment
    {
        Лево = 0,
        Право = 1
    }
}
