﻿namespace osfDesigner
{
    public enum LinkLabelLinkBehavior
    {
        ВсегдаПодчеркнутый = 1,
        НеПодчеркнутый = 3,
        ПодчеркнутыйПриНаведении = 2,
        СистемныйПоУмолчанию = 0
    }
}
