﻿namespace osfDesigner
{
    public enum ListViewAlignment
    {
        Верх = 2,
        Лево = 1,
        ПоСетке = 5,
        ПоУмолчанию = 0
    }
}
