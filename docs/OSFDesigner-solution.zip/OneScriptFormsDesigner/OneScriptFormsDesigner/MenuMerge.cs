﻿namespace osfDesigner
{
    public enum MenuMerge
    {
        Добавить = 0,
        Заменить = 1,
        ОбъединитьМеню = 2,
        Удалить = 3
    }
}
