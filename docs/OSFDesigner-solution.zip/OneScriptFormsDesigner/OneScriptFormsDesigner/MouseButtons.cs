﻿namespace osfDesigner
{
    [System.Flags]

    public enum MouseButtons
    {
        Левая = 1048576,
        Правая = 2097152,
        Средняя = 4194304
    }
}
