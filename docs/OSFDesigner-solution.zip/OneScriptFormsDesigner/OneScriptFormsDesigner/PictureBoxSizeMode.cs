﻿namespace osfDesigner
{
    public enum PictureBoxSizeMode
    {
        АвтоРазмер = 2,
        Пропорционально = 4,
        РастянутьИзображение = 1,
        Стандартный = 0,
        ЦентрИзображения = 3
    }
}
