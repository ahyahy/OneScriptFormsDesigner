﻿namespace osfDesigner
{
    public enum PropertySort
    {
        БезСортировки = 0,
        ПоАлфавиту = 1,
        ПоКатегориям = 2,
        ПоКатегориямПоАлфавиту = 3
    }
}
