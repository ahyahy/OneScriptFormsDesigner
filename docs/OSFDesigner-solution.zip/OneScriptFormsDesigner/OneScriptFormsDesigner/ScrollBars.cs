﻿namespace osfDesigner
{
    public enum ScrollBars
    {
        Вертикальная = 2,
        Горизонтальная = 1,
        Обе = 3,
        Отсутствие = 0
    }
}
