﻿namespace osfDesigner
{
    public enum SelectionMode
    {
        МножественныйПростой = 2,
        МножественныйРасширенный = 3,
        Одиночный = 1,
        Отсутствие = 0
    }
}
