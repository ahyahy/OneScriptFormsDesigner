﻿namespace osfDesigner
{
    public enum SortOrder
    {
        Отсутствие = 0,
        ПоВозрастанию = 1,
        ПоУбыванию = 2
    }
}
