﻿namespace osfDesigner
{
    public enum SortType
    {
        Булево = 3,
        ДатаВремя = 2,
        Текст = 0,
        Число = 1
    }
}
