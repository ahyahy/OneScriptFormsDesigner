﻿namespace osfDesigner
{
    public enum StatusBarPanelAutoSize
    {
        Отсутствие = 1,
        ПоСодержимому = 3,
        Растяжимое = 2
    }
}
