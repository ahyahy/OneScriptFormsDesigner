﻿namespace osfDesigner
{
    public enum StatusBarPanelBorderStyle
    {
        Отсутствие = 1,
        Рельефная = 2,
        Утопленная = 3
    }
}
