﻿namespace osfDesigner
{
    public enum TabAlignment
    {
        Верх = 0,
        Лево = 2,
        Низ = 1,
        Право = 3
    }
}
