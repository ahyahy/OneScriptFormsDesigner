﻿namespace osfDesigner
{
    public enum TabAppearance
    {
        Кнопки = 1,
        ПлоскиеКнопки = 2,
        Стандартный = 0
    }
}
