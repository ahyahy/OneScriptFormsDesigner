﻿namespace osfDesigner
{
    public enum TabSizeMode
    {
        ЗаполнитьВправо = 1,
        Постоянный = 2,
        Стандартный = 0
    }
}
