﻿namespace osfDesigner
{
    public enum ToolBarAppearance
    {
        Плоский = 1,
        Стандартный = 0
    }
}
