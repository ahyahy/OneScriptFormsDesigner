﻿namespace osfDesigner
{
    public enum ToolBarButtonStyle
    {
        КнопкаВыпадающегоСписка = 4,
        Разделитель = 3,
        СтандартнаяТрехмерная = 1,
        Тумблер = 2
    }
}
