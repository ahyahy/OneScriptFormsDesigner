﻿namespace osfDesigner
{
    public enum ToolBarTextAlign
    {
        Понизу = 0,
        Право = 1
    }
}
