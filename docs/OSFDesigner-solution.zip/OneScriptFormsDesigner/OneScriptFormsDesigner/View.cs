﻿namespace osfDesigner
{
    public enum View
    {
        БольшойЗначок = 0,
        МаленькийЗначок = 2,
        Подробно = 1,
        Список = 3
    }
}
